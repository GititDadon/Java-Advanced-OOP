module Animal {
}