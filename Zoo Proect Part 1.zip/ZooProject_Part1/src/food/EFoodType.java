package food;

public enum EFoodType {
	MEAT,NOTFOOD,VEGTABLE
}
