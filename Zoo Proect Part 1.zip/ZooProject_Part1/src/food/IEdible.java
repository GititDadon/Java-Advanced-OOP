package food;

public interface IEdible {
	public EFoodType getFoodtype();

}
